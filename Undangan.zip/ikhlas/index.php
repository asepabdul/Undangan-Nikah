<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Undangan Pernikahan</title>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/brands.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/solid.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.0/font/bootstrap-icons.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://cdn.jsdelivr.net/npm/html5shiv@3.7.3/dist/html5shiv.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/respond.js@1.4.2/dest/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>

  <!-- banner -->
  <div class="banner-img"><img src="img/banner.jpeg" width="100%;" height="650px;"></div>
  <div class="jumbo text-center">
    <div class="container">
      <div class="banner-text">
      <h1 style="font-family: 'Playball', cursive;" class="lead">Aqkly & Hilda</h1>
      <br><br>
      <p>Kepada Bpk/Ibu/Saudara/i</p>
      <?php $get = str_replace('_', ' ', $_GET['to']); if(empty($_GET['to'])){ ?>
          <p class="lead" style="font-family: 'Playball', cursive;color:white;font-size: 25px">Bapak / Ibu</p>
          <?php }else{ ?>
          <p class="lead" style="font-family: 'Playball', cursive;color:white;font-size: 25px"><?= $get ?></p>
          <?php } ?>
      <p>Tanpa mengurangi rasa hormat,kami mengundang anda untuk hadir di acara pernikahan kami.</p>
      <br>
      <button type="button" class="btn btn-primary mb" onclick="buka()"><i class="bi bi-envelope-open-fill"></i></i> Open Invitation</button>
      </div>
    </div>
  </div>
  <!-- akhir banner -->

  <div id="carousel-example-generic" class="carousel slide" data-ride="carousel" style="display: none; background-attachment: fixed;">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
     <li data-target="#carousel-example-generic" data-slide-to="3"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox" style="background-attachment: fixed;">
    <div class="item active" style="background-attachment: fixed;">
      <img src="img/full/2.jpeg" class="d-block w-100" alt="Promo hilang" style="height: 650px; width: 100%;" >
      <div class="carousel-caption">
        <img src="img/user1.png" class="img-circle" style="z-index: 2; height: 330px; width: 330px;">
        <h2 style="font-family: 'Playball', cursive; z-index: 5;" class="lead">Aqkly Hermawan</h2>
        <p style="z-index: 2;">Putra dari bpk.Ahmad Zaenudin/Ibu Titing Nuryani</p>
        <h1 style="z-index: 2;">&</h1>
        <h1 style="font-family: 'Playball', cursive; z-index: 2;" class="lead">Hilda Yanti</h1>
        <p style="z-index: 2;">Putra dari bpk.Adam/Ibu Hawa</p>
    </div>
  </div>

    <div class="item">
      <img src="img/full/3.jpeg" class="d-block w-100" alt="Promo hilang" style="height: 650px; width: 100%;">
      <div class="carousel-caption">
        <img src="img/user1.png" class="img-circle" style="z-index: 2; height: 330px; width: 330px;">
        <h2 style="font-family: 'Playball', cursive; z-index: 5;" class="lead">Asep Abdur Rofik</h2>
        <p style="z-index: 2;">Putra dari bpk.Ahmad Zaenudin/Ibu Titing Nuryani</p>
        <h1 style="z-index: 2;">&</h1>
        <h1 style="font-family: 'Playball', cursive; z-index: 2;" class="lead">Anya Geraldine</h1>
        <p style="z-index: 2;">Putra dari bpk.Adam/Ibu Hawa</p>
      </div>
    </div>

    <div class="item">
      <img src="img/full/4.jpeg" class="d-block w-100" alt="Promo hilang" style="height: 650px; width: 100%;">
      <div class="carousel-caption">
        <img src="img/user1.png" class="img-circle" style="z-index: 2; height: 330px; width: 330px;">
        <h2 style="font-family: 'Playball', cursive; z-index: 5;" class="lead">Asep Abdur Rofik</h2>
        <p style="z-index: 2;">Putra dari bpk.Ahmad Zaenudin/Ibu Titing Nuryani</p>
        <h1 style="z-index: 2;">&</h1>
        <h1 style="font-family: 'Playball', cursive; z-index: 2;" class="lead">Anya Geraldine</h1>
        <p style="z-index: 2;">Putra dari bpk.Adam/Ibu Hawa</p>
      </div>
    </div>

    <div class="item">
      <img src="img/full/5.jpeg" class="d-block w-100" alt="Promo hilang" style="height: 650px; width: 100%;">
      <div class="carousel-caption">
        <img src="img/user1.png" class="img-circle" style="z-index: 2; height: 330px; width: 330px;">
        <h2 style="font-family: 'Playball', cursive; z-index: 5;" class="lead">Asep Abdur Rofik</h2>
        <p style="z-index: 2;">Putra dari bpk.Ahmad Zaenudin/Ibu Titing Nuryani</p>
        <h1 style="z-index: 2;">&</h1>
        <h1 style="font-family: 'Playball', cursive; z-index: 2;" class="lead">Anya Geraldine</h1>
        <p style="z-index: 2;">Putra dari bpk.Adam/Ibu Hawa</p>
      </div>
    </div>
  </div>

  <!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<!-- class="glyphicon glyphicon-chevron-left"
class="glyphicon glyphicon-chevron-right" -->

  <!-- showcase -->
 <!--  <div id="dua" class="jumbotron text-center" style="display: none;" style="z-index: 5;">
    <img src="img/user1.png" class="img-circle" style="z-index: 2;"> -->
   <!--  <h2 style="font-size: 30px; color: lightskyblue; text-align: center;">~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~</h2> -->
    <!-- <h2 style="font-family: 'Playball', cursive; z-index: 5;" class="lead">Asep Abdur Rofik</h2>
    <p style="z-index: 2;">Putra dari bpk.Ahmad Zaenudin/Ibu Titing Nuryani</p>
    <h1 style="z-index: 2;">&</h1>
    <h1 style="font-family: 'Playball', cursive; z-index: 2;" class="lead">Anya Geraldine</h1>
    <p style="z-index: 2;">Putra dari bpk.Adam/Ibu Hawa</p> -->
    <!-- <h2>Minggu, 17 Juli 2022</h2> -->
   <!--  <h2 style="font-size: 30px; color: lightskyblue; text-align: center;">~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~</h2> -->
  <!-- </div> -->
  <!-- showcase -->

  <!-- about -->
  <section class="about" id="about" style="display: none;">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <h3 class="text-center" style="margin-top: 30px; font-weight: bold; font-family: 'Playball', cursive;" class="lead">Tentang Kami</h3>
          <h2 class="text-center" style="font-weight: bold; font-family: 'Playball', cursive;" class="lead">Pasangan Mempelai</h2>
          <hr>
        </div>
      </div>

    <div class="row">
      <div class="col-sm-5 col-sm-offset-1 text-justify text-center">
        <div class="contain text-center">
          <img src="img/asep.png" style="margin-right: 8px;">
          <h1 style="font-family: 'Playball', cursive;" class="lead">Aqkly Hermawan</h1>
          <p style="font-weight: bold; font-size: 20px;">Putra dari</p>
          <p style="font-size: 17px;">bpk.Ahmad Zaenudin/Ibu Titing Nuryani</p>
        </div>
      </div>

      <div class="col-sm-5 text-justify text-center">
        <div class="contain text-center">
          <img src="img/hilda.png" style="margin-left: 15px;">
          <h1 style="font-family: 'Playball', cursive;" class="lead">Hilda Yanti</h1>
          <p style="font-weight: bold; font-size: 20px;">Putri dari</p>
          <p style="font-size: 17px;">bpk.Adam/Ibu Hawa</p>
        </div>
      </div>
    </div>
  </section>
    <!-- akhir about -->
<!-- 
  <div id="garis" class="garis" style="display: none;">
      <h2 style="font-size: 30px; color: lightskyblue; text-align: center;">_______________________________________________________</h2>
  </div> -->

  <!-- portofolio -->
    <section class="portofolio" id="portofolio" style="display: none;">
      <div class="container elemen">
        <div class="row">
          <div class="col-sm-12">
            <h2 class="text-center" style="margin-top: 60px; font-family: 'Playball', cursive;" class="lead">Galeri</h2>
            <hr>
          </div>
        </div>

         <div class="row">
           <div class="col-sm-4">
            <a href="#gambar-1" class="thumbnail">
              <img src="img/portofolio/1.jpeg">
            </a>
           </div>
          <div class="overlay" id="gambar-1">
            <a href="#portofolio" class="close">x close</a>
            <a href="#gambar-6" class="prev">prev</a>
            <img src="img/full/1.jpeg" alt="MYC">
            <a href="#gambar-2" class="next">next</a>
          </div>

            <div class="col-sm-4">
            <a href="#gambar-2" class="thumbnail">
              <img src="img/portofolio/2.jpeg">
            </a>
           </div>
           <div class="overlay" id="gambar-2">
            <a href="#portofolio" class="close">x close</a>
            <a href="#gambar-1" class="prev">prev</a>
            <img src="img/full/2.jpeg" alt="MYC">
            <a href="#gambar-3" class="next">next</a>
          </div>

            <div class="col-sm-4">
            <a href="#gambar-3" class="thumbnail">
              <img src="img/portofolio/3.jpeg">
            </a>
           </div>
           <div class="overlay" id="gambar-3">
            <a href="#portofolio" class="close">x close</a>
            <a href="#gambar-2" class="prev">prev</a>
            <img src="img/full/3.jpeg" alt="MYC">
            <a href="#gambar-4" class="next">next</a>
          </div>

            <div class="col-sm-4">
            <a href="#gambar-4" class="thumbnail">
              <img src="img/portofolio/4.jpeg">
            </a>
           </div>
           <div class="overlay" id="gambar-4">
            <a href="#portofolio" class="close">x close</a>
            <a href="#gambar-3" class="prev">prev</a>
            <img src="img/full/4.jpeg" alt="MYC">
            <a href="#gambar-5" class="next">next</a>
          </div>

            <div class="col-sm-4">
            <a href="#gambar-5" class="thumbnail">
              <img src="img/portofolio/5.jpeg">
            </a>
           </div>
           <div class="overlay" id="gambar-5">
            <a href="#portofolio" class="close">x close</a>
            <a href="#gambar-4" class="prev">prev</a>
            <img src="img/full/5.jpeg" alt="MYC">
            <a href="#gambar-6" class="next">next</a>
          </div>

            <div class="col-sm-4">
            <a href="#gambar-6" class="thumbnail">
              <img src="img/portofolio/6.jpg">
            </a>
           </div>
           <div class="overlay" id="gambar-6">
            <a href="#portofolio" class="close">x close</a>
            <a href="#gambar-5" class="prev">prev</a>
            <img src="img/full/6.jpg" alt="MYC">
            <a href="#gambar-1" class="next">next</a>
          </div>

        </div>  
      </div>
    </section>
    <!-- akhir portofolio -->

    <!-- kata -->
  <div id="contact" class="contact text-center" style="display: none;">
    <div class="row">
    <div class="col-sm-9 col-sm-offset-2 kata" style="margin-top: 120px;">
        <p class="lead text-center" style="font-family: 'Playball', cursive;" class="lead">
            " Dan di antara tanda-tanda kekuasaan-Nya diciptakan-Nya untukmu pasangan hidup dari jenismu sendiri supaya kamu dapat ketenangan hati dan dijadikannya kasih sayang di antara kamu. Sesungguhnya yang demikian menjadi tanda-tanda kebesaran-Nya bagi orang-orang yang berpikir. "
        </p>
        <p class="lead text-center" style="font-family: 'Playball', cursive;" class="lead">- Q.S. Ar-Rum: 21 -</p> 
    </div>
    </div>
  </div>
  <!-- kata -->

  <!-- tanggal -->
  <section class="tanggal" id="tanggal" style="display: none;">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <h3 class="text-center" style="margin-top: 60px; font-weight: bold; font-family: 'Playball', cursive;" class="lead">Acara</h3>
          <h2 class="text-center" style="font-weight: bold; font-family: 'Playball', cursive;" class="lead" >Pernikahan Kami</h2>
          <hr>
        </div>
      </div>

    <div class="row">
      <div class="col-sm-6  text-justify text-center">
        <div class="contain text-center">
          <i class="bi bi-receipt" style="font-size: 50px; color: lightskyblue;"></i>
          <h2 style="font-size: 30px; font-weight: bold; color: lightskyblue; font-family: 'Playball', cursive;" class="lead">Akad Nikah</h2>
          <hr>
          <div>
          <i class="bi bi-calendar-week-fill" style="font-size: 50px; color: lightskyblue;"></i>
          <p style="font-size: 15px;">Sabtu, 20 Desember 2022</p>
          <i class="bi bi-clock-fill" style="font-size: 50px; color: lightskyblue;"></i>
          <p style="font-size: 15px;">08.00 - 10.30 WIB</p>
          </div>
          <hr>
          <p style="font-weight: bold; font-size: 15px;">Lokasi:</p>
          <p style="font-size: 15px;">Masjid Istiqlal</p>
        </div>
      </div>

       <div class="col-sm-6 text-justify text-center">
        <div class="contain text-center">
          <i class="bi bi-receipt" style="font-size: 50px; color: lightskyblue;"></i>
          <h2 style="font-size: 30px; font-weight: bold; color: lightskyblue; font-family: 'Playball', cursive;" class="lead">Resepsi Pernikahan</h2>
          <hr>
          <div>
          <i class="bi bi-calendar-week-fill" style="font-size: 50px; color: lightskyblue;"></i>
          <p style="font-size: 15px;">Sabtu, 20 Desember 2022</p>
          <i class="bi bi-clock-fill" style="font-size: 50px; color: lightskyblue;"></i>
          <p style="font-size: 15px;">10.30 - Selesai</p>
          </div>
          <hr>
          <p style="font-weight: bold; font-size: 15px;">Lokasi:</p>
          <p style="font-size: 15px;">Masjid Istiqlal</p>
        </div>
      </div>
    </div>
  </section>
    <!-- akhir about -->

  <!-- maps -->
  <div id="maps" class="maps" style="display: none;">
    <div class="col-sm-12 text-center">
       <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3959.80503870666!2d107.65461691397255!3d-7.032187394920612!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e68eb406f2b13a3%3A0x9e7d4d26a1d58b2f!2sA&#39;Abdurrofik%20Guesthouse!5e0!3m2!1sid!2sid!4v1655280303810!5m2!1sid!2sid" width="1200" height="450" style="border: 5px solid lightskyblue; margin-top: 50px; border-radius: 7px; cursor: crosshair;" title="maps" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe> 
       <br><br>
       <a href="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3959.80503870666!2d107.65461691397255!3d-7.032187394920612!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e68eb406f2b13a3%3A0x9e7d4d26a1d58b2f!2sA&#39;Abdurrofik%20Guesthouse!5e0!3m2!1sid!2sid!4v1655280303810!5m2!1sid!2sid" title="maps" target="blank" class="btn btn-primary"><i class="bi bi-envelope-open-fill"></i>Open Maps</a>
       <br><br><br>
    </div>
  </div>
  <!-- maps -->

   <!-- Section Music -->
    <section id="music" class="section lima" style="display: none; background-color: #eee;">
    <div class="container">
      <br><br>
      <h2 style="font-family: 'Playball', cursive;" class="lead">Untuk yang berhalangan hadir kami tambahkan fitur dibawah ini</h2>
      <br>
        <button type="button" class="btn btn-primary mb" data-toggle="modal" data-target="#kirim"><i class="fa fa-envelope"></i> Kirim Angpau</button>

        <button type="button" class="btn btn-primary mb" data-toggle="modal" data-target="#kirim2"><i class="fa fa-envelope"></i> Kirim Kado</button>

        <h6 style="margin-bottom: 0; font-size: 19px;">Music ? Klik untuk memutar</h6>
        <div class="music-container" id="music-container">
        <div class="music-info">
            <h4 id="title"></h4>
            <div class="progress-container" id="progress-container">
            <div class="progress" id="progress"></div>
            </div>
        </div>

        <audio src="music/lebih-indah.mp3" id="audio"></audio>

      <div class="img-container">
          <img src="image/lebih-indah.jpg" alt="music-cover" id="cover" />
      </div>

        <div class="navigation">
          <button id="prev" class="action-btn">
            <i class="fas fa-backward"></i>
          </button>
          <button id="play" class="action-btn action-btn-big">
            <i class="fas fa-play"></i>
          </button>
          <button id="next" class="action-btn">
            <i class="fas fa-forward"></i>
          </button>
        </div>
      </div>

      <h3 style="font-family: 'Playball', cursive; font-size: 30px; font-weight: bold;">Save The Date</h3>
        <h4 style="font-family: 'Playball', cursive; font-size: 20px;">Sabtu, 20 desember 2022</h4>
        <h5 id="counter" style="background-color: lightskyblue; font-size: 20px; font-weight: bold;"><strong>11 days</strong>, <strong>9 minutes</strong> and <strong>53 seconds</strong></h5>

        <div id=hide>
            <form>
                <h3>Countdown date</h3>
                <fieldset id="countdown-start"><span>
                    <input id="year" type="number" min="-9999" max="9999" step="1" value="2022" size="4" placeholder="year"><label for="month">-</label><input id="month" type="number" min="1" max="12" step="1" value="12" size="2" placeholder="month"><label for="date">-</label><input id="date" type="number" min="1" max="31" step="1" value="20" size="2" placeholder="day"></span>
                    <span><label for="hours">&nbsp;</label><input id="hours" type="number" min="0" max="9" step="1" value="14" size="2" placeholder="hrs"><label for="minutes">:</label><input id="minutes" type="number" min="0" max="59" step="1" value="00" size="2" placeholder="min"><label for="seconds">:</label><input id="seconds" type="number" min="0" max="59" step="1" value="00" size="2" placeholder="sec"><label for="milliseconds">.</label><input id="milliseconds" type="number" min="0" max="999" step="1" value="0" size="3" placeholder="ms"></span>
                    <span id="timezone">UTC+07:00</span>
                </fieldset>

                <h3>Display units</h3>
                <fieldset id="countdown-units"><span>
                    <label for="units-millennia"><input id="units-millennia" type="checkbox" value="1024">millennia</label>
                    <label for="units-centuries"><input id="units-centuries" type="checkbox" value="512">centuries</label>
                    <label for="units-decades"><input id="units-decades" type="checkbox" value="256">decades</label>
                </span><span>
                    <label for="units-years"><input id="units-years" type="checkbox" value="128">years</label>
                    <label for="units-months"><input id="units-months" type="checkbox" value="64">months</label>
                    <label for="units-weeks"><input id="units-weeks" type="checkbox" value="32">weeks</label>
                    <label for="units-days"><input id="units-days" type="checkbox" value="16">days</label>
                </span><span>
                    <label for="units-hours"><input id="units-hours" type="checkbox" value="8">hours</label>
                    <label for="units-minutes"><input id="units-minutes" type="checkbox" value="4">minutes</label>
                    <label for="units-seconds"><input id="units-seconds" type="checkbox" value="2">seconds</label>
                    <label for="units-milliseconds"><input id="units-milliseconds" type="checkbox" value="1">milliseconds</label>
                </span><span>
                    <label for="empty-label">empty</label><input id="empty-label" type="text" value="now!">
                </span><span>
                    <label for="max-units">max</label><input id="max-units" type="number" min="0" max="11" value="11">
                    <label for="frac-digits">digits</label><input id="frac-digits" type="number" min="0" max="20" value="0">
                <span></span></span></fieldset>
            </form>

            <h3>Timespan object</h3>
            <pre id="timespan"></pre>
        </div>

        </div>
    </section>

     <!-- contact -->
    <section class="rsvp" id="rsvp" style="display: none;">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <h2 class="text-center" style="margin-top: 60px; font-size: 35px;font-family: 'Playball', cursive;" class="lead">RSVP</h2>
            <hr>
          </div>
        </div>

         <div class="row">
          <div class="col-sm-8 col-sm-offset-2">
            <form>
              <div class="form-group">
                <label for="nama">Nama</label>
                <input type="text" id="nama" class="form-control" placeholder="masukkan nama">
              </div>

               <div class="form-group">
                <label for="nama">Alamat</label>
                <input type="text" id="alamat" class="form-control" placeholder="masukkan alamat">
              </div>

          <label for="konfir">Konfirmasi</label>
          <div class="radio">
            <label>
              <input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked>
              Iya, Saya akan datang
            </label>
          </div>
          <div class="radio">
            <label>
              <input type="radio" name="optionsRadios" id="optionsRadios2" value="option2">
              Maaf saya tidak akan datang
            </label>
          </div>
          <div class="radio">
            <label>
              <input type="radio" name="optionsRadios" id="optionsRadios3" value="option3">
              Saya masih ragu
            </label>
          </div>

              <button type="button" class="btn btn-primary">Reservation Via Whatsapp</button>

            </form>
          </div>
        </div>  
      </div>
    </section>
    <!-- akhir contact -->

     <!-- contact -->
    <section class="pesan" id="pesan" style="display: none; background-color: #eee;">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
             <h3 class="text-center" style="margin-top: 60px; font-weight: bold;font-family: 'Playball', cursive;" class="lead">Kirimkan Pesan</h3>
            <h2 class="text-center" style="font-family: 'Playball', cursive;" class="lead">Untuk Kami Berdua</h2>
            <hr>
          </div>
        </div>

         <div class="row">
          <div class="col-sm-8 col-sm-offset-2">
            <form>
              <div class="form-group">
                <label for="nama"></label>
                <input type="text" id="nama" class="form-control" placeholder="isikan nama anda">
              </div>

              <div class="form-group">
                <label for="pesan"></label>
                <textarea class="form-control" rows="10" placeholder="Berikan ucapan dan doa restu"></textarea>
              </div>

              <button type="button" class="btn btn-primary">Kirimkan Ucapan</button>

            </form>
          </div>
        </div>  
      </div>
    </section>
    <!-- akhir contact -->

    <!-- giftcards -->
     <!-- Gift Card Section -->
    <section id="gift-cards" class="section bg-light enam" style="display: none;">
        <div class="container">
          <h2 style="font-family: 'Playball', cursive; font-size: 20px; color: lightskyblue; font-weight: bold;" class="lead">Jangan ragu untuk datang, kami sudah berkoordinasi dengan semua pihak terkait pencegahan penularan COVID-19. Acara kami akan mengikuti segala prosedur protokol kesehatan untuk mencegah penularan COVID-19. So, don't be panic, we look forward to seeing you there!</h2>
            <div class="gift-cards">
                <div>
                    <img src="img/masker.png">
                    <!-- <img src="img/cards.png" alt=""> -->
                </div>
                <div class="container">
                    <p style="font-family: 'Playball', cursive;" class="lead">Tamu undangan wajib menggunakan masker.</p>
                </div>
                <div>
                    <img src="img/suhu.png">
                </div>
                <div class="container">
                    <p style="font-family: 'Playball', cursive;" class="lead">Suhu Tubuh Normal (dibawah 37,5°C)</p>
                </div>
                <div>
                    <img src="img/jarak.png">
                </div>
                <div class="container">
                    <p style="font-family: 'Playball', cursive;" class="lead">Jaga jarak antar orang minimal sekitar 2 meter</p>
                </div>
                <div>
                    <img src="img/cuci.png">
                </div>
                <div class="container">
                    <p style="font-family: 'Playball', cursive;" class="lead">Cuci tangan menggunakan air dan sabun atau menggunakan hand sanitizer</p>
                </div>
                <br>
                <h2 style="font-family: 'Playball', cursive; font-size: 20px; color: lightskyblue; font-weight: bold;" class="lead">*Bagi para tamu undangan diharapkan mengikuti protokol pencegahan COVID-19.</h2>
            </div>
        </div>
    </section>

     <!-- Footer -->
    <footer style="display: none;" class="tujuh">
        <div class="footer-bottom text-center" style="color: white; ">
            Copyright &copy; 2022 - Asep Abdur Rofik - All Rights Reserved.
            <div class="icon" style="margin-top: 10px;">
                <a href="https://api.whatsapp.com/send?phone=6285647582894" <i class="bi bi-whatsapp" title="whatsapp" target="blank"></i></a>
                <a href="https://mail.google.com/mail/u/0/#inbox" class="fa fa-envelope" title="e-mail" target="blank"></a>
                <a href="https://m.facebook.com/?_rdr" class="fa-brands fa-facebook" title="facebook" target="blank"></a>
                <a href="https://www.instagram.com/" class="fa-brands fa-instagram" title="instagram" target="blank"></a>
                <a href="https://twitter.com/home" class="fa-brands fa-twitter"title="twitter" target="blank"></a>
            </div>
            <p style="font-family: 'Playball', cursive; color: white; font-size: 5px; text-align: left;" class="lead">*Soundtrack by Because you loved me - Celine Dion (sax cvover Graziatto)*</p>
        </div>
    </footer>

    <!-- kirim -->
    <div class="modal" id="kirim" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" style="color:#000">Kirim Angpau</h4>
            </div>
            
            <div class="modal-body" style="font-size: 11px">
                <label style="color: #000">No Rekening</label>&nbsp; &nbsp;
                <span style="color: #000">: 32093094093 a/n Hambaallah</span> 
                <hr>
                <label style="color: #000">Konfirmasi by Whatsapp</label> &nbsp; &nbsp;&nbsp;
                <a class="link" style="color: white; background-color: lightskyblue;" href="https://api.whatsapp.com/send?phone=6285647582894">: <i class="bi bi-send" class="btn btn-primary btn-sm"></i> Kirim Pesan</a>

            </div>

            <div class="modal-footer">
              <button type="button" class="btn btn-primary btn-sm" data-dismiss="modal" aria-label="Close">Tutup</button>
            </div>
    </div>
    </div>
    </div>

    <!-- kirim -->
    <div class="modal" id="kirim2" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" style="color:#000">Kirim Kado</h4>
            </div>
            
            <div class="modal-body" style="font-size: 11px">
                <label style="color: #000">Alamat</label>&nbsp; &nbsp;
                <span style="color: #000">: Kp.Jelekong RT.02 RW.04 Kel.Jelekong Kec.Baleendah Kab.Bandung</span> 
                <hr class="text-left">
                <label style="color: #000">Konfirmasi</label> &nbsp; &nbsp;&nbsp;
                <a style="color: white; background-color: lightskyblue;"  href="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3959.80503870666!2d107.65461691397255!3d-7.032187394920612!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e68eb406f2b13a3%3A0x9e7d4d26a1d58b2f!2sA&#39;Abdurrofik%20Guesthouse!5e0!3m2!1sid!2sid!4v1655280303810!5m2!1sid!2sid" target="_blank">: <i class="bi bi-send" class="btn btn-primary mb"></i> Open Maps</a>

            </div>

            <div class="modal-footer">
              <button type="button" class="btn btn-primary btn-sm" data-dismiss="modal" aria-label="Close">Tutup</button>
            </div>
    </div>
    </div>



    <script src="http://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/coutdown.min.js"></script>
    <script src="js/demo.js"></script>
    <!-- <script src="script.js"></script> -->

    <script type="text/javascript">
        $(document).ready(function(){
            $("#hide").hide();
        });

        const musicContainer = document.getElementById("music-container");
        const playBtn = document.getElementById("play");
        const prevBtn = document.getElementById("prev");
        const nextBtn = document.getElementById("next");

        const audio = document.getElementById("audio");
        const progress = document.getElementById("progress");
        const progressContainer = document.getElementById("progress-container");
        const title = document.getElementById("title");
        const cover = document.getElementById("cover");

        // song titles
        const songs = ["celinedion"];

        // keep track of song
        let songIndex = 0;

        // initially load song details in DOM
        loadSong(songs[songIndex]);

        // update song details
        function loadSong(song) {
          title.innerHTML = song;
          audio.src = `music/${song}.mp3`;
          cover.src = `image/${song}.jpg`;
        }

        // play song
        function playSong() {
          musicContainer.classList.add("play");
          playBtn.querySelector("i.fas").classList.remove("fa-play");
          playBtn.querySelector("i.fas").classList.add("fa-pause");

          audio.play();
        }

        // pause song
        function pauseSong() {
          musicContainer.classList.remove("play");
          playBtn.querySelector("i.fas").classList.remove("fa-pause");
          playBtn.querySelector("i.fas").classList.add("fa-play");

          audio.pause();
        }

        // prev song
        function prevSong() {
          songIndex--;

          if (songIndex < 0) {
            songIndex = songs.length - 1;
          }

          loadSong(songs[songIndex]);

          playSong();
        }

        // next song
        function nextSong() {
          songIndex++;

          if (songIndex > songs.length - 1) {
            songIndex = 0;
          }

          loadSong(songs[songIndex]);

          playSong();
        }

        // update progress bar
        function updateProgress(e) {
          const { duration, currentTime } = e.srcElement;
          const progressPercent = (currentTime / duration) * 100;
          progress.style.width = `${progressPercent}%`;
        }
        // set progress bar
        function setProgress(e) {
          const width = this.clientWidth; //total width song
          const clickX = e.offsetX;
          const duration = audio.duration;

          audio.currentTime = (clickX / width) * duration;
        }

        // Event listeners
        playBtn.addEventListener("click", () => {
          const isPlaying = musicContainer.classList.contains("play");

          if (isPlaying) {
            pauseSong();
          } else {
            playSong();
          }
        });

        // Change song
        prevBtn.addEventListener("click", prevSong);
        nextBtn.addEventListener("click", nextSong);

        // time song update
        audio.addEventListener("timeupdate", updateProgress);

        // click on progress bar
        progressContainer.addEventListener("click", setProgress);

        // song ends
        audio.addEventListener("ended", nextSong);
    </script>












    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->

    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>

    <script src="script.js"></script>


    <script type="text/javascript">
      function buka()
        {
            $(".banner-img").css('display', 'none');
            $(".banner-text").css('display', 'none');
            
            $("#satu").css('display', '');
            $("#dua").css('display', '');
            $("#about").css('display', '');
            $("#garis").css('display', '');
            $("#portofolio").css('display', '');
            $("#contact").css('display', '');
            $("#text").css('display', '');
            $("#coba").css('display', '');
            $("#tanggal").css('display', '');
            $("#maps").css('display', '');
            $("#music").css('display', '');
            $("#rsvp").css('display', '');
            $("#pesan").css('display', '');
            $("#gift-cards").css('display', '');
            $("#carousel-example-generic").css('display', '');
      
            $(".satu").css('display', '');
            $(".dua").css('display', '');
            $(".tiga").css('display', '');
            $(".empat").css('display', '');
            $(".lima").css('display', '');
            $(".enam").css('display', '');
            $(".tujuh").css('display', '');


            playSong();
        }
    </script>
  </body>
</html>